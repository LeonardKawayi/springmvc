package com.lagou.demo.utils;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author zhangzhenkun <zhangzhenkun@kuaishou.com>
 * Created on 2020-01-28
 */
public class ConstantsUtil {

    public static final Map<String, List<String>> SECURITY_USER_NAME_MAP = new HashMap<>();

    static {
        List<String> zhangSanSecurityList = Arrays.asList("handler01", "handler02");
        SECURITY_USER_NAME_MAP.put("zhangsan", zhangSanSecurityList);

        List<String> liSiSecurityList = Arrays.asList("handler03", "handler04");
        SECURITY_USER_NAME_MAP.put("lisi", liSiSecurityList);
    }
}
