package com.lagou.demo.controller;

import com.lagou.demo.service.IDemoService;
import com.lagou.edu.mvcframework.annotations.LagouAutowired;
import com.lagou.edu.mvcframework.annotations.LagouController;
import com.lagou.edu.mvcframework.annotations.LagouRequestMapping;
import com.lagou.edu.mvcframework.annotations.Security;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@LagouController
@LagouRequestMapping("/demo")
public class DemoController {


    @LagouAutowired
    private IDemoService demoService;


    /**
     * URL: /demo/query?name=lisi
     * @param request
     * @param response
     * @param name
     * @return
     */
    @LagouRequestMapping("/query")
    public String query(HttpServletRequest request, HttpServletResponse response,String name) {
        return demoService.get(name);
    }

    @LagouRequestMapping("/handler01")
    @Security
    public String handler01(HttpServletRequest request, HttpServletResponse response,String username) {
        System.out.println("handler01");
        return "handler01";
    }

    @LagouRequestMapping("/handler02")
    @Security
    public String handler02(HttpServletRequest request, HttpServletResponse response,String username) {
        System.out.println("handler02");
        return "handler02";
    }

    @LagouRequestMapping("/handler03")
    @Security
    public String handler03(HttpServletRequest request, HttpServletResponse response,String username) {
        System.out.println("handler03");
        return "handler03";
    }

    @LagouRequestMapping("/handler04")
    @Security
    public String handler04(HttpServletRequest request, HttpServletResponse response,String username) {
        System.out.println("handler04");
        return "handler04";
    }
}
