package com.lagou.edu.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * @author zhangzhenkun <zhangzhenkun@kuaishou.com>
 * Created on 2020-02-09
 */
@Controller
@RequestMapping("/test")
public class TestController {

    @RequestMapping("/test")
    @ResponseBody
    public String testMvc () {
        System.out.println("ok!");
        return "ok";
    }
}
