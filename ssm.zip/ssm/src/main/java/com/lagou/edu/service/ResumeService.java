package com.lagou.edu.service;

import com.lagou.edu.pojo.Resume;

import java.util.List;

public interface ResumeService {
    //新增和修改
    public Resume saveOrUpdate(Resume resume) throws Exception;
    //删除
    public void delete(Resume resume) throws Exception;

    void deleteById (long id);

    //查询所有
    public List<Resume> findAll() throws Exception;

}
