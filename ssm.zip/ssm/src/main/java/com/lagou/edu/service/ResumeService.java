package com.lagou.edu.service;

import java.util.List;

import com.lagou.edu.pojo.Resume;

public interface ResumeService {
    //新增和修改
    public Resume saveOrUpdate(Resume resume) throws Exception;
    //删除
    public void delete(Resume resume) throws Exception;

    void deleteById(long id);

    //查询所有
    public List<Resume> findAll() throws Exception;

}
