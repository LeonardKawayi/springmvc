package com.lagou.edu.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lagou.edu.mapper.ResumeDao;
import com.lagou.edu.pojo.Resume;
import com.lagou.edu.service.ResumeService;

@Repository(value = "resumeService")
public class ResumeServiceImpl implements ResumeService {


    @Autowired
    private ResumeDao resumeDao;

    public ResumeDao getResumeDao() {
        return resumeDao;
    }

    public void setResumeDao(ResumeDao resumeDao) {
        this.resumeDao = resumeDao;
    }

    @Override
    public Resume saveOrUpdate(Resume resume) throws Exception {
        return resumeDao.save(resume);
    }

    @Override
    public void delete(Resume resume) throws Exception {
        resumeDao.delete(resume);
    }

    @Override
    public void deleteById(long id) {
        resumeDao.deleteById(id);
    }

    @Override
    public List<Resume> findAll() throws Exception {
        List<Resume> depts = resumeDao.findAll();
        return depts;
    }


}



