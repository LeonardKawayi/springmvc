package com.lagou.edu.service.impl;

import com.lagou.edu.dao.ResumeDao;
import com.lagou.edu.pojo.Resume;
import com.lagou.edu.service.ResumeService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import java.util.List;

@Repository(value = "resumeService")
public class resumeServiceImpl implements ResumeService {


    @Autowired
   private  ResumeDao resumeDao;
    public ResumeDao getResumeDao() {
        return resumeDao;
    }

    public void setResumeDao(ResumeDao resumeDao) {
        this.resumeDao = resumeDao;
    }

    @Override
    public Resume saveOrUpdate(Resume resume) throws Exception {
       return resumeDao.save(resume);
    }

    @Override
    public void delete(Resume resume) throws Exception {
        resumeDao.delete(resume);
    }

    @Override
    public void deleteById(long id) {
        resumeDao.deleteById(id);
    }

    @Override
    public List<Resume> findAll() throws Exception {
        List<Resume> depts = resumeDao.findAll();
        return depts;
    }


}



