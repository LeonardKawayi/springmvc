package com.lagou.edu.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.lagou.edu.pojo.Resume;
import com.lagou.edu.pojo.User;
import com.lagou.edu.service.ResumeService;

@Controller
public class ResumeController {

    @Autowired
    private ResumeService resumeService;

    //登录界面
    @RequestMapping("/")
    public String home() {
        return "forward:login.jsp";
    }

    //登录功能
    @RequestMapping("/login")
    public String login(User user, Model model, HttpSession session) {
        String username = user.getUsername();
        String password = user.getPassword();
        if ("admin".equals(username) && "admin".equals(password)) {
            session.setAttribute("USER_SESSION", user);
            return "redirect:http://localhost:8080/dept_list";
        }
        model.addAttribute("msg", "用户名或密码错误，请重新登录！");
        return "login";
    }


    //登录后界面显示
    @RequestMapping("/dept_list")
    public ModelAndView findAll() throws Exception {
        ModelAndView mv = new ModelAndView();
        List<Resume> depts = resumeService.findAll();
        mv.addObject("depts", depts);
        mv.setViewName("/dept_list");
        System.out.println(mv);
        return mv;

    }

    //增加
    @RequestMapping("/add")
    public String insert(HttpServletRequest req, Resume resume) throws Exception {

        Resume insert = resumeService.saveOrUpdate(resume);
        req.setAttribute("insert", insert);

        return "redirect:http://localhost:8080/dept_list";
    }

    //删除
    @RequestMapping("/del")
    public String delete(int id) {
        String str = String.valueOf(id);
        long value = Long.parseLong(str);
        resumeService.deleteById(value);
        return "redirect:http://localhost:8080/dept_list";
    }

    //修改
    @RequestMapping("/modify")
    public String modify(HttpServletRequest req, Resume resume) throws Exception {
        int id = Math.toIntExact(resume.getId());
        String str = String.valueOf(id);
        long value = Long.parseLong(str);
        resumeService.deleteById(value);
        Resume insert = resumeService.saveOrUpdate(resume);
        req.setAttribute("insert", insert);
        return "redirect:http://localhost:8080/dept_list";
    }
}